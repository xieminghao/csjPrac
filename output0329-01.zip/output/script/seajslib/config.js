// /************SeaJs配置***************/
// seajs.config({
//     base: '/res/js/lot',
// 	alias:{
// 	    'Base': 'seajslib/base.js',
// 	    'BaseExtend': 'seajslib/baseExt.js',
// 	    'ClassConfig': 'seajslib/classconfig.js'
// 	},
// 	preload: 'Waiting',
// 	map: [
//         ['.js', '.js']
// 	]
// });
